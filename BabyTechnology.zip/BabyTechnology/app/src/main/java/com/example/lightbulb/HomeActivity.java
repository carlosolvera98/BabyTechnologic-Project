package com.example.lightbulb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference myRef;
    DatabaseReference myRef2;
    DatabaseReference myRef3;
    DatabaseReference myRef4;

    private PendingIntent pendingIntent;
    private final static String CHANNEL_ID = "NOTIFICACION";
    private final static int NOTIFICACION_ID = 0;

    private TextView mTextViewData;
    private DatabaseReference mDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //LAMP
        Switch led = (Switch)findViewById(R.id.Led);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("led");

        led.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                if(b){
                    myRef.setValue(1);
                }else{
                    myRef.setValue(0);
                }
            }
        });

        //CUNA
        Switch cuna = (Switch)findViewById(R.id.Cuna);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef2 = database.getReference("servo2");

        cuna.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean c) {
                if(c){
                    myRef2.setValue(1);
                }else{
                    myRef2.setValue(0);
                }
            }
        });

        //MOVIL
        Switch movil = (Switch)findViewById(R.id.Movil);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef3 = database.getReference("servo1");

        movil.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean d) {
                if(d){
                    myRef3.setValue(1);
                }else{
                    myRef3.setValue(0);
                }
            }
        });

        //Buzzer
        Switch buzzer = (Switch)findViewById(R.id.buzzer);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef4 = database.getReference("sound");

        buzzer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean d) {
                if(d){
                    myRef4.setValue(1);
                }else{
                    myRef4.setValue(0);
                }
            }
        });

        mTextViewData = (TextView) findViewById(R.id.textViewData);
        mDataBase = FirebaseDatabase.getInstance().getReference();
        mDataBase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    double temp = Double.parseDouble(dataSnapshot.child("temperatura").getValue().toString());
                    double hum = Double.parseDouble(dataSnapshot.child("humedad").getValue().toString());
                    mTextViewData.setText("Temperatura: " + temp + "˙C           Humedad: " + hum);


                    if(temp >= 32.00){

                        setPendingIntent();
                        createNotificationChannel();
                        createNotification();

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setPendingIntent(){
        Intent intent = new Intent(this, MainActivity.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(MainActivity.class);
        stackBuilder.addNextIntent(intent);
        pendingIntent = stackBuilder.getPendingIntent(1, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "Noticacion";
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    private void createNotification(){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID);
        builder.setSmallIcon(R.drawable.common_full_open_on_phone);
        builder.setContentTitle("El cuarto del bebé està muy caliente");
        builder.setContentText("Temperatura del cuarto mayor a 27˙C");
        builder.setColor(Color.BLUE);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setLights(Color.MAGENTA, 1000, 1000);
        builder.setVibrate(new long[]{1000,1000,1000,1000,1000});
        builder.setDefaults(Notification.DEFAULT_SOUND);

        builder.setContentIntent(pendingIntent);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(getApplicationContext());
        notificationManagerCompat.notify(NOTIFICACION_ID, builder.build());
    }

}
